# FeastFlow — Catering Quote Calculator

A responsive catering services landing page and simple quote calculator.

## Features
- Responsive layout using Flexbox
- Catering services section
- Basic, Standard, and Premium packages
- Guest count and package selector
- Live estimate calculation in Indian Rupees (₹)

## Run
1. Extract the ZIP file.
2. Open `index.html` in your browser (or use VS Code Live Server).
3. Enter the number of guests and choose a package to see the quote update.

## Project files
- `index.html`: page structure
- `style.css`: styling and responsive layout
- `script.js`: quote calculation

This is a demo project; contact details and pricing are sample values.
