const guestsInput = document.getElementById('guests');
const packageSelect = document.getElementById('package');
const totalDisplay = document.getElementById('total');

function updateQuote() {
  const guests = Math.max(1, Number.parseInt(guestsInput.value, 10) || 1);
  const pricePerPerson = Number(packageSelect.value);
  const total = guests * pricePerPerson;
  totalDisplay.textContent = total.toLocaleString('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0
  });
}
guestsInput.addEventListener('input', updateQuote);
packageSelect.addEventListener('change', updateQuote);
updateQuote();
